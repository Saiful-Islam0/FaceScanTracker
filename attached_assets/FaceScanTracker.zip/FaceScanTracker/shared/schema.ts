import { pgTable, text, serial, integer, timestamp, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User/Person schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  fullName: text("full_name").notNull(),
  employeeId: text("employee_id").notNull().unique(),
  department: text("department"),
  email: text("email"),
  enrollmentDate: timestamp("enrollment_date").defaultNow().notNull(),
  faceData: text("face_data"), // Storing face descriptor as a string (JSON)
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  enrollmentDate: true,
});

// Attendance schema
export const attendance = pgTable("attendance", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
  status: text("status").notNull(), // 'present', 'absent', 'late'
  type: text("type").notNull(), // 'check-in', 'check-out'
});

export const insertAttendanceSchema = createInsertSchema(attendance).omit({
  id: true,
  timestamp: true,
});

// Extended schemas with validation
export const userFormSchema = insertUserSchema.extend({
  password: z.string().min(6, { message: "Password must be at least 6 characters" }),
  fullName: z.string().min(2, { message: "Full name is required" }),
  employeeId: z.string().min(2, { message: "Employee ID is required" }),
  email: z.string().email({ message: "Invalid email address" }).optional().or(z.literal('')),
});

export const attendanceQuerySchema = z.object({
  date: z.string().optional(),
  userId: z.number().optional(),
  status: z.enum(['present', 'absent', 'late']).optional(),
});

// Analytics schema for insights and predictions
export const analyticsQuerySchema = z.object({
  userId: z.number().optional(),
  startDate: z.string(),
  endDate: z.string(),
  type: z.enum(["attendance", "trends", "prediction"])
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type UserForm = z.infer<typeof userFormSchema>;

export type Attendance = typeof attendance.$inferSelect;
export type InsertAttendance = z.infer<typeof insertAttendanceSchema>;
export type AttendanceQuery = z.infer<typeof attendanceQuerySchema>;
export type AnalyticsQuery = z.infer<typeof analyticsQuerySchema>;

// Face data type for recognition
export type FaceDescriptor = number[];
