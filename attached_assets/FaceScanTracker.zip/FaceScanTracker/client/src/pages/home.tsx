import { useState } from "react";
import CameraView from "@/components/camera-view";
import AttendanceList from "@/components/attendance-list";
import ReportsView from "@/components/reports-view";
import EnrollmentView from "@/components/enrollment-view";
import BottomNavigation from "@/components/bottom-navigation";

// Main tabs
type TabId = "camera" | "attendance" | "reports" | "enrollment";

export default function Home() {
  const [activeTab, setActiveTab] = useState<TabId>("camera");
  
  // Change active tab
  const handleTabChange = (tabId: string) => {
    setActiveTab(tabId as TabId);
  };
  
  return (
    <div className="flex flex-col h-full">
      {/* App content area */}
      <div className="flex-1 overflow-hidden relative">
        {/* Tab content */}
        <div className={activeTab === "camera" ? "block h-full" : "hidden"}>
          <CameraView />
        </div>
        
        <div className={activeTab === "attendance" ? "block h-full" : "hidden"}>
          <AttendanceList />
        </div>
        
        <div className={activeTab === "reports" ? "block h-full" : "hidden"}>
          <ReportsView />
        </div>
        
        <div className={activeTab === "enrollment" ? "block h-full" : "hidden"}>
          <EnrollmentView />
        </div>
      </div>
      
      {/* Bottom Navigation */}
      <BottomNavigation 
        activeTab={activeTab}
        onChange={handleTabChange}
      />
    </div>
  );
}
