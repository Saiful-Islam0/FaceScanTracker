import { useEffect, useState, useRef, useCallback } from "react";
import * as facemesh from "@tensorflow-models/face-landmarks-detection";
import "@tensorflow/tfjs-core";
import "@tensorflow/tfjs-backend-webgl";

type FaceDetectionBox = {
  topLeft: [number, number];
  bottomRight: [number, number];
};

export const useFaceDetection = () => {
  const [model, setModel] = useState<facemesh.FaceLandmarksDetector | null>(null);
  const [faces, setFaces] = useState<FaceDetectionBox[]>([]);
  const [isModelLoading, setIsModelLoading] = useState(false);
  const [isDetecting, setIsDetecting] = useState(false);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const requestAnimationRef = useRef<number | null>(null);

  // Load the facemesh model
  useEffect(() => {
    const loadModel = async () => {
      setIsModelLoading(true);
      try {
        const model = await facemesh.createDetector(
          facemesh.SupportedModels.MediaPipeFaceMesh,
          {
            runtime: "mediapipe", 
            solutionPath: "https://cdn.jsdelivr.net/npm/@mediapipe/face_mesh",
            maxFaces: 1 // We only need to detect one face for attendance
          }
        );
        setModel(model);
      } catch (error) {
        console.error("Failed to load face detection model:", error);
      } finally {
        setIsModelLoading(false);
      }
    };

    loadModel();

    // Cleanup on unmount
    return () => {
      if (requestAnimationRef.current) {
        cancelAnimationFrame(requestAnimationRef.current);
      }
    };
  }, []);

  // Function to detect faces in the video stream
  const detectFaces = useCallback(async () => {
    if (!model || !videoRef.current || !videoRef.current.readyState === 4) {
      requestAnimationRef.current = requestAnimationFrame(detectFaces);
      return;
    }

    try {
      const predictions = await model.estimateFaces(videoRef.current);

      // Extract the bounding boxes from the predictions
      const detectedFaces = predictions.map((prediction) => {
        const box = prediction.box;
        return {
          topLeft: [box.xMin, box.yMin] as [number, number],
          bottomRight: [box.xMax, box.yMax] as [number, number],
        };
      });

      setFaces(detectedFaces);
    } catch (error) {
      console.error("Error detecting faces:", error);
    }

    if (isDetecting) {
      requestAnimationRef.current = requestAnimationFrame(detectFaces);
    }
  }, [model, isDetecting]);

  // Start/stop face detection
  useEffect(() => {
    if (isDetecting) {
      detectFaces();
    } else if (requestAnimationRef.current) {
      cancelAnimationFrame(requestAnimationRef.current);
    }
  }, [isDetecting, detectFaces]);

  // Function to start detection
  const startDetection = useCallback(() => {
    setIsDetecting(true);
  }, []);

  // Function to stop detection
  const stopDetection = useCallback(() => {
    setIsDetecting(false);
    if (requestAnimationRef.current) {
      cancelAnimationFrame(requestAnimationRef.current);
      requestAnimationRef.current = null;
    }
  }, []);

  return {
    videoRef,
    faces,
    isModelLoading,
    isDetecting,
    startDetection,
    stopDetection,
  };
};
