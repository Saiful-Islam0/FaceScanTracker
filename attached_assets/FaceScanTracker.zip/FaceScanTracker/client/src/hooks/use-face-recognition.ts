import { useState, useCallback } from "react";
import * as faceapi from "face-api.js";
import { User } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

// Load models from CDN
const MODEL_URL = "https://justadudewhohacks.github.io/face-api.js/models";

export const useFaceRecognition = () => {
  const [isModelLoading, setIsModelLoading] = useState(false);
  const [isModelLoaded, setIsModelLoaded] = useState(false);
  const [recognizedUser, setRecognizedUser] = useState<User | null>(null);
  const [isRecognizing, setIsRecognizing] = useState(false);
  
  // Initialize face-api models
  const initializeModels = useCallback(async () => {
    if (isModelLoaded) return;
    
    setIsModelLoading(true);
    try {
      // Load required face-api.js models
      await Promise.all([
        faceapi.nets.faceRecognitionNet.loadFromUri(MODEL_URL),
        faceapi.nets.faceLandmark68Net.loadFromUri(MODEL_URL),
        faceapi.nets.ssdMobilenetv1.loadFromUri(MODEL_URL)
      ]);
      setIsModelLoaded(true);
    } catch (error) {
      console.error("Error loading face recognition models:", error);
    } finally {
      setIsModelLoading(false);
    }
  }, [isModelLoaded]);
  
  // Extract face descriptor from image/video
  const extractFaceDescriptor = useCallback(async (
    imageOrVideo: HTMLImageElement | HTMLVideoElement
  ): Promise<Float32Array | null> => {
    if (!isModelLoaded) {
      await initializeModels();
    }
    
    try {
      // Detect all faces and get descriptors
      const detections = await faceapi.detectAllFaces(imageOrVideo)
        .withFaceLandmarks()
        .withFaceDescriptors();
      
      if (detections.length === 0) {
        return null;
      }
      
      // Return the descriptor of the first face found
      return detections[0].descriptor;
    } catch (error) {
      console.error("Error extracting face descriptor:", error);
      return null;
    }
  }, [isModelLoaded, initializeModels]);
  
  // Save face descriptor for enrollment
  const saveFaceDescriptor = useCallback(async (
    userId: number, 
    descriptor: Float32Array
  ): Promise<boolean> => {
    try {
      await apiRequest("PUT", `/api/users/${userId}/face`, {
        faceData: Array.from(descriptor)
      });
      return true;
    } catch (error) {
      console.error("Error saving face descriptor:", error);
      return false;
    }
  }, []);
  
  // Recognize face against all enrolled users
  const recognizeFace = useCallback(async (
    imageOrVideo: HTMLImageElement | HTMLVideoElement
  ): Promise<User | null> => {
    if (isRecognizing) return null;
    
    setIsRecognizing(true);
    setRecognizedUser(null);
    
    try {
      // Extract descriptor from current face
      const descriptor = await extractFaceDescriptor(imageOrVideo);
      if (!descriptor) {
        return null;
      }
      
      // Get all enrolled users
      const response = await fetch("/api/users");
      const users: User[] = await response.json();
      
      // Filter users with face data
      const enrolledUsers = users.filter(user => user.faceData);
      
      if (enrolledUsers.length === 0) {
        return null;
      }
      
      // Create face matcher with loaded face data
      const labeledDescriptors = enrolledUsers.map(user => {
        // Parse the face data from string to array
        const faceData = JSON.parse(user.faceData as string) as number[];
        return new faceapi.LabeledFaceDescriptors(
          user.id.toString(),
          [new Float32Array(faceData)]
        );
      });
      
      const faceMatcher = new faceapi.FaceMatcher(labeledDescriptors);
      
      // Match the current face against the enrolled faces
      const match = faceMatcher.findBestMatch(descriptor);
      
      if (match.label === 'unknown') {
        return null;
      }
      
      // Find the matching user
      const matchedUser = users.find(user => user.id.toString() === match.label);
      if (matchedUser) {
        setRecognizedUser(matchedUser);
        return matchedUser;
      }
      
      return null;
    } catch (error) {
      console.error("Error in face recognition:", error);
      return null;
    } finally {
      setIsRecognizing(false);
    }
  }, [extractFaceDescriptor, isRecognizing]);
  
  return {
    isModelLoading,
    isModelLoaded,
    isRecognizing,
    recognizedUser,
    initializeModels,
    extractFaceDescriptor,
    saveFaceDescriptor,
    recognizeFace,
  };
};
