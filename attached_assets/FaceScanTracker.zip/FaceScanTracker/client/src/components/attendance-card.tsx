import { format, parseISO } from "date-fns";

type AttendanceCardProps = {
  user: {
    id: number;
    fullName: string;
    employeeId: string;
  };
  status: string;
  timestamp: string;
};

export default function AttendanceCard({ user, status, timestamp }: AttendanceCardProps) {
  // Format time to display
  const time = format(parseISO(timestamp), "h:mm a");
  
  // Determine status style
  const getStatusStyle = () => {
    switch (status) {
      case "present":
        return "bg-green-100 text-green-800";
      case "absent":
        return "bg-red-100 text-red-800";
      case "late":
        return "bg-orange-100 text-orange-800";
      default:
        return "bg-slate-100 text-slate-800";
    }
  };
  
  // Capitalize status for display
  const displayStatus = status.charAt(0).toUpperCase() + status.slice(1);
  
  return (
    <div className="attendance-card flex items-center p-3 bg-white rounded-lg shadow-sm">
      <div className="w-10 h-10 rounded-full bg-slate-200 mr-3 flex items-center justify-center">
        <div className="text-slate-500 font-medium">
          {user.fullName.split(' ').map(n => n[0]).join('')}
        </div>
      </div>
      <div className="flex-1">
        <div className="flex justify-between">
          <h4 className="font-medium text-sm">{user.fullName}</h4>
          <span className={`text-xs px-2 py-0.5 rounded-full ${getStatusStyle()}`}>
            {displayStatus}
          </span>
        </div>
        <div className="flex justify-between mt-1">
          <p className="text-xs text-slate-500">ID: {user.employeeId}</p>
          <p className="text-xs text-slate-500">{time}</p>
        </div>
      </div>
    </div>
  );
}
