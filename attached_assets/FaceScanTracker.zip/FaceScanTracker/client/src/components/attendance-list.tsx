import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { 
  FileDown, 
  Filter, 
  ChevronLeft, 
  ChevronRight, 
  Search
} from "lucide-react";
import { Input } from "@/components/ui/input";
import AttendanceCard from "./attendance-card";
import { Skeleton } from "@/components/ui/skeleton";
import { Attendance } from "@shared/schema";
import { format, addDays, subDays, parseISO } from "date-fns";

export default function AttendanceList() {
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [searchTerm, setSearchTerm] = useState("");
  
  // Format the date
  const formattedDate = format(selectedDate, "yyyy-MM-dd");
  const displayDate = format(selectedDate, "MMMM d, yyyy");
  const isToday = format(selectedDate, "yyyy-MM-dd") === format(new Date(), "yyyy-MM-dd");
  
  // Fetch attendance data
  const { data: attendanceData, isLoading, error } = useQuery({
    queryKey: ['/api/attendance/date', formattedDate],
    queryFn: async () => {
      const response = await fetch(`/api/attendance/date/${formattedDate}`);
      if (!response.ok) {
        throw new Error("Failed to fetch attendance");
      }
      return response.json();
    }
  });
  
  // Fetch attendance summary
  const { data: summary, isLoading: isSummaryLoading } = useQuery({
    queryKey: ['/api/attendance/summary', formattedDate],
    queryFn: async () => {
      const response = await fetch(`/api/attendance/summary/${formattedDate}`);
      if (!response.ok) {
        throw new Error("Failed to fetch attendance summary");
      }
      return response.json();
    }
  });
  
  // Navigation helpers
  const goToPreviousDay = () => {
    setSelectedDate(prev => subDays(prev, 1));
  };
  
  const goToNextDay = () => {
    setSelectedDate(prev => addDays(prev, 1));
  };
  
  // Search filter
  const filteredAttendance = attendanceData ? 
    attendanceData.filter((record: any) => 
      record.user && record.user.fullName.toLowerCase().includes(searchTerm.toLowerCase())
    ) : [];
  
  // Group attendance by user ID to show the latest attendance for each user
  const groupedAttendance = filteredAttendance.reduce((acc: Record<number, any>, curr: any) => {
    if (!acc[curr.user.id] || new Date(curr.timestamp) > new Date(acc[curr.user.id].timestamp)) {
      acc[curr.user.id] = curr;
    }
    return acc;
  }, {});
  
  // Export attendance data to CSV
  const exportAttendance = () => {
    if (!attendanceData) return;
    
    // Create CSV content
    let csvContent = "ID,Name,Employee ID,Status,Time\n";
    
    Object.values(groupedAttendance).forEach((record: any) => {
      const time = format(parseISO(record.timestamp), "HH:mm:ss");
      csvContent += `${record.user.id},${record.user.fullName},${record.user.employeeId},${record.status},${time}\n`;
    });
    
    // Create download link
    const blob = new Blob([csvContent], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.setAttribute("href", url);
    a.setAttribute("download", `attendance-${formattedDate}.csv`);
    a.click();
    URL.revokeObjectURL(url);
  };
  
  return (
    <div className="h-full">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 bg-white shadow-sm">
        <h1 className="text-lg font-semibold text-slate-800">Attendance</h1>
        <div className="flex items-center space-x-2">
          <Button variant="ghost" size="icon" className="rounded-full">
            <Filter className="h-5 w-5" />
          </Button>
          <Button onClick={exportAttendance} variant="ghost" size="icon" className="rounded-full">
            <FileDown className="h-5 w-5" />
          </Button>
        </div>
      </div>
      
      {/* Date selector */}
      <div className="p-4">
        <div className="flex items-center justify-between mb-4">
          <Button
            onClick={goToPreviousDay}
            variant="ghost"
            size="icon"
            className="rounded-full"
          >
            <ChevronLeft className="h-5 w-5" />
          </Button>
          <h2 className="font-semibold">
            {isToday ? "Today, " : ""}{displayDate}
          </h2>
          <Button
            onClick={goToNextDay}
            variant="ghost"
            size="icon"
            className="rounded-full"
          >
            <ChevronRight className="h-5 w-5" />
          </Button>
        </div>
        
        {/* Attendance summary */}
        <div className="grid grid-cols-3 gap-3 mb-4">
          <div className="bg-white rounded-lg p-3 shadow-sm">
            <p className="text-xs text-slate-500 mb-1">Present</p>
            {isSummaryLoading ? (
              <Skeleton className="h-6 w-14" />
            ) : (
              <div className="flex items-baseline">
                <span className="text-xl font-bold text-green-500">
                  {summary?.present || 0}
                </span>
                <span className="text-xs text-slate-500 ml-1">
                  / {summary?.total || 0}
                </span>
              </div>
            )}
          </div>
          <div className="bg-white rounded-lg p-3 shadow-sm">
            <p className="text-xs text-slate-500 mb-1">Absent</p>
            {isSummaryLoading ? (
              <Skeleton className="h-6 w-14" />
            ) : (
              <div className="flex items-baseline">
                <span className="text-xl font-bold text-red-500">
                  {summary?.absent || 0}
                </span>
                <span className="text-xs text-slate-500 ml-1">
                  / {summary?.total || 0}
                </span>
              </div>
            )}
          </div>
          <div className="bg-white rounded-lg p-3 shadow-sm">
            <p className="text-xs text-slate-500 mb-1">Late</p>
            {isSummaryLoading ? (
              <Skeleton className="h-6 w-14" />
            ) : (
              <div className="flex items-baseline">
                <span className="text-xl font-bold text-orange-500">
                  {summary?.late || 0}
                </span>
                <span className="text-xs text-slate-500 ml-1">
                  / {summary?.total || 0}
                </span>
              </div>
            )}
          </div>
        </div>
      </div>
      
      {/* Attendance list */}
      <div className="px-4 pb-20">
        <div className="flex justify-between items-center mb-3">
          <h3 className="font-medium text-sm text-slate-600">Personnel</h3>
          <div className="relative">
            <Input
              type="text"
              placeholder="Search..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-8 pr-3 py-1 text-sm bg-slate-100 rounded-full w-36 focus:outline-none focus:ring-1 focus:ring-primary-500"
            />
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 h-4 w-4" />
          </div>
        </div>
        
        <div className="space-y-3">
          {isLoading ? (
            // Loading skeleton
            Array.from({ length: 3 }).map((_, index) => (
              <div key={index} className="bg-white rounded-lg p-3 shadow-sm">
                <div className="flex items-center">
                  <Skeleton className="h-10 w-10 rounded-full mr-3" />
                  <div className="flex-1">
                    <Skeleton className="h-4 w-24 mb-2" />
                    <Skeleton className="h-3 w-32" />
                  </div>
                  <Skeleton className="h-5 w-16 rounded-full" />
                </div>
              </div>
            ))
          ) : error ? (
            <div className="text-center p-4 text-red-500">
              Error loading attendance data
            </div>
          ) : filteredAttendance.length === 0 ? (
            <div className="text-center p-4 text-slate-500">
              No attendance records found for this date
            </div>
          ) : (
            Object.values(groupedAttendance).map((record: any) => (
              <AttendanceCard
                key={record.id}
                user={record.user}
                status={record.status}
                timestamp={record.timestamp}
              />
            ))
          )}
        </div>
      </div>
    </div>
  );
}
