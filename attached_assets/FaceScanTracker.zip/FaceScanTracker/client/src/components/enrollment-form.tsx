import { useState, useRef, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { User, userFormSchema } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { useFaceRecognition } from "@/hooks/use-face-recognition";
import { Check, RotateCcw, Camera } from "lucide-react";

type EnrollmentFormProps = {
  currentStep: number;
  formData: Partial<User>;
  onNextStep: (data: Partial<User>) => void;
  onPreviousStep: () => void;
  onComplete: () => void;
};

export default function EnrollmentForm({
  currentStep,
  formData,
  onNextStep,
  onPreviousStep,
  onComplete
}: EnrollmentFormProps) {
  const { toast } = useToast();
  const [faceDetected, setFaceDetected] = useState(false);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const { extractFaceDescriptor } = useFaceRecognition();
  
  // Form setup
  const { register, handleSubmit, formState: { errors } } = useForm({
    resolver: zodResolver(userFormSchema),
    defaultValues: {
      fullName: formData.fullName || "",
      employeeId: formData.employeeId || "",
      department: formData.department || "",
      email: formData.email || "",
      password: formData.password || ""
    }
  });
  
  // Create user mutation
  const createUserMutation = useMutation({
    mutationFn: async (userData: Partial<User>) => {
      return apiRequest("POST", "/api/users", userData);
    },
    onSuccess: async (response) => {
      const newUser = await response.json();
      
      toast({
        title: "User Created",
        description: "User information saved successfully",
        variant: "default"
      });
      
      // Move to next step with the new user data
      onNextStep(newUser);
      
      // Invalidate users query
      queryClient.invalidateQueries({ queryKey: ['/api/users'] });
    },
    onError: (error) => {
      console.error("Error creating user:", error);
      toast({
        title: "Error",
        description: "Failed to create user",
        variant: "destructive"
      });
    }
  });
  
  // Save face data mutation
  const saveFaceDataMutation = useMutation({
    mutationFn: async ({ userId, faceData }: { userId: number, faceData: number[] }) => {
      return apiRequest("PUT", `/api/users/${userId}/face`, { faceData });
    },
    onSuccess: () => {
      toast({
        title: "Face Data Saved",
        description: "Facial features registered successfully",
        variant: "default"
      });
      
      // Move to final step
      onNextStep({});
      
      // Invalidate users query
      queryClient.invalidateQueries({ queryKey: ['/api/users'] });
    },
    onError: (error) => {
      console.error("Error saving face data:", error);
      toast({
        title: "Error",
        description: "Failed to save face data",
        variant: "destructive"
      });
    }
  });
  
  // Set up camera for face capture
  useEffect(() => {
    if (currentStep === 2) {
      startCamera();
    } else {
      stopCamera();
    }
    
    return () => {
      stopCamera();
    };
  }, [currentStep]);
  
  // Start camera
  const startCamera = async () => {
    try {
      const newStream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: "user",
          width: { ideal: 640 },
          height: { ideal: 480 }
        },
        audio: false
      });
      
      setStream(newStream);
      if (videoRef.current) {
        videoRef.current.srcObject = newStream;
      }
    } catch (error) {
      console.error("Error accessing camera:", error);
      toast({
        title: "Camera Error",
        description: "Could not access the camera. Please check permissions.",
        variant: "destructive"
      });
    }
  };
  
  // Stop camera
  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
  };
  
  // Capture face image
  const captureFaceImage = () => {
    if (!videoRef.current || !canvasRef.current) return;
    
    const video = videoRef.current;
    const canvas = canvasRef.current;
    const context = canvas.getContext('2d');
    
    if (!context) return;
    
    // Set canvas dimensions to match video
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    
    // Draw video frame to canvas
    context.drawImage(video, 0, 0, canvas.width, canvas.height);
    
    // Convert canvas to data URL
    const imageDataUrl = canvas.toDataURL('image/png');
    setCapturedImage(imageDataUrl);
    
    // Check if face is detected
    checkForFace(video);
  };
  
  // Reset capture
  const resetCapture = () => {
    setCapturedImage(null);
    setFaceDetected(false);
  };
  
  // Check if face is in the image
  const checkForFace = async (video: HTMLVideoElement) => {
    try {
      const descriptor = await extractFaceDescriptor(video);
      
      if (descriptor) {
        setFaceDetected(true);
        toast({
          title: "Face Detected",
          description: "Face successfully captured",
          variant: "default"
        });
      } else {
        setFaceDetected(false);
        toast({
          title: "No Face Detected",
          description: "Please position your face in the center and try again",
          variant: "destructive"
        });
        setCapturedImage(null);
      }
    } catch (error) {
      console.error("Error detecting face:", error);
      setFaceDetected(false);
      toast({
        title: "Detection Error",
        description: "Error processing facial features",
        variant: "destructive"
      });
    }
  };
  
  // Handle form submission for step 1
  const onSubmitUserInfo = (data: any) => {
    createUserMutation.mutate(data);
  };
  
  // Handle face data submission for step 2
  const onSubmitFaceData = async () => {
    if (!formData.id || !capturedImage || !faceDetected) {
      toast({
        title: "Missing Data",
        description: "Please capture a valid face image first",
        variant: "destructive"
      });
      return;
    }
    
    try {
      // Convert data URL to Image for face processing
      const img = new Image();
      img.src = capturedImage;
      
      // Wait for image to load
      await new Promise((resolve) => {
        img.onload = resolve;
      });
      
      // Extract face descriptor
      const descriptor = await extractFaceDescriptor(img);
      
      if (!descriptor) {
        throw new Error("Failed to extract face features");
      }
      
      // Save face data
      saveFaceDataMutation.mutate({
        userId: formData.id,
        faceData: Array.from(descriptor)
      });
    } catch (error) {
      console.error("Error processing face data:", error);
      toast({
        title: "Processing Error",
        description: "Failed to process face data",
        variant: "destructive"
      });
    }
  };
  
  // Render form based on current step
  const renderStepContent = () => {
    switch (currentStep) {
      case 1:
        return (
          <form onSubmit={handleSubmit(onSubmitUserInfo)} className="space-y-4">
            <div>
              <Label htmlFor="fullName" className="block text-sm font-medium text-slate-700 mb-1">
                Full Name
              </Label>
              <Input 
                id="fullName"
                {...register("fullName")}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-primary-500 focus:border-primary-500"
              />
              {errors.fullName && (
                <p className="text-red-500 text-xs mt-1">{errors.fullName.message}</p>
              )}
            </div>
            
            <div>
              <Label htmlFor="employeeId" className="block text-sm font-medium text-slate-700 mb-1">
                Employee ID
              </Label>
              <Input 
                id="employeeId"
                {...register("employeeId")}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-primary-500 focus:border-primary-500"
              />
              {errors.employeeId && (
                <p className="text-red-500 text-xs mt-1">{errors.employeeId.message}</p>
              )}
            </div>
            
            <div>
              <Label htmlFor="department" className="block text-sm font-medium text-slate-700 mb-1">
                Department
              </Label>
              <Select defaultValue={formData.department || ""}>
                <SelectTrigger className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-primary-500 focus:border-primary-500">
                  <SelectValue placeholder="Select department" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Engineering">Engineering</SelectItem>
                  <SelectItem value="Marketing">Marketing</SelectItem>
                  <SelectItem value="Finance">Finance</SelectItem>
                  <SelectItem value="Human Resources">Human Resources</SelectItem>
                  <SelectItem value="Operations">Operations</SelectItem>
                </SelectContent>
              </Select>
              <input 
                type="hidden" 
                {...register("department")}
                value={formData.department || ""}
              />
            </div>
            
            <div>
              <Label htmlFor="email" className="block text-sm font-medium text-slate-700 mb-1">
                Email
              </Label>
              <Input 
                id="email"
                type="email"
                {...register("email")}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-primary-500 focus:border-primary-500"
              />
              {errors.email && (
                <p className="text-red-500 text-xs mt-1">{errors.email.message}</p>
              )}
            </div>
            
            <div>
              <Label htmlFor="password" className="block text-sm font-medium text-slate-700 mb-1">
                Password
              </Label>
              <Input 
                id="password"
                type="password"
                {...register("password")}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-primary-500 focus:border-primary-500"
              />
              {errors.password && (
                <p className="text-red-500 text-xs mt-1">{errors.password.message}</p>
              )}
            </div>
            
            <div className="mt-6">
              <Button 
                type="submit"
                disabled={createUserMutation.isPending}
                className="w-full bg-primary-600 text-white py-3 rounded-lg font-medium"
              >
                {createUserMutation.isPending ? "Saving..." : "Next: Face Scan"}
              </Button>
            </div>
          </form>
        );
        
      case 2:
        return (
          <div className="space-y-4">
            <div className="bg-black rounded-lg overflow-hidden relative">
              {!capturedImage ? (
                <video
                  ref={videoRef}
                  autoPlay
                  playsInline
                  muted
                  className="w-full aspect-video object-cover"
                />
              ) : (
                <img 
                  src={capturedImage} 
                  alt="Captured face" 
                  className="w-full aspect-video object-cover"
                />
              )}
              
              <canvas ref={canvasRef} className="hidden" />
              
              <div className="absolute bottom-4 left-0 w-full flex justify-center space-x-4">
                {!capturedImage ? (
                  <Button
                    onClick={captureFaceImage}
                    className="w-14 h-14 bg-primary-600 rounded-full flex items-center justify-center shadow-lg hover:bg-primary-700"
                  >
                    <Camera className="h-6 w-6 text-white" />
                  </Button>
                ) : (
                  <>
                    <Button
                      onClick={resetCapture}
                      className="w-12 h-12 bg-white rounded-full flex items-center justify-center shadow-lg hover:bg-slate-100"
                    >
                      <RotateCcw className="h-5 w-5 text-slate-700" />
                    </Button>
                    
                    {faceDetected && (
                      <Button
                        onClick={onSubmitFaceData}
                        className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center shadow-lg hover:bg-green-600"
                      >
                        <Check className="h-5 w-5 text-white" />
                      </Button>
                    )}
                  </>
                )}
              </div>
            </div>
            
            <div className="text-center text-sm text-slate-600">
              <p>Position your face in the frame and capture a clear image</p>
            </div>
            
            <div className="flex justify-between mt-4">
              <Button
                onClick={onPreviousStep}
                className="px-4 py-2 border border-slate-300 rounded-lg text-slate-700"
                variant="outline"
              >
                Back
              </Button>
              
              <Button
                onClick={onSubmitFaceData}
                disabled={!faceDetected || saveFaceDataMutation.isPending}
                className="px-4 py-2 bg-primary-600 text-white rounded-lg"
              >
                {saveFaceDataMutation.isPending ? "Saving..." : "Next: Confirm"}
              </Button>
            </div>
          </div>
        );
        
      case 3:
        return (
          <div className="space-y-6">
            <div className="text-center">
              <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Check className="h-10 w-10 text-green-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Enrollment Complete</h3>
              <p className="text-slate-600">
                {formData.fullName} has been successfully enrolled in the system.
              </p>
            </div>
            
            <div className="bg-slate-50 p-4 rounded-lg">
              <h4 className="font-medium mb-2">Enrollment Details</h4>
              <ul className="space-y-2 text-sm">
                <li className="flex justify-between">
                  <span className="text-slate-500">Name:</span>
                  <span className="font-medium">{formData.fullName}</span>
                </li>
                <li className="flex justify-between">
                  <span className="text-slate-500">Employee ID:</span>
                  <span className="font-medium">{formData.employeeId}</span>
                </li>
                <li className="flex justify-between">
                  <span className="text-slate-500">Department:</span>
                  <span className="font-medium">{formData.department}</span>
                </li>
                <li className="flex justify-between">
                  <span className="text-slate-500">Enrollment Date:</span>
                  <span className="font-medium">
                    {new Date().toLocaleDateString()}
                  </span>
                </li>
              </ul>
            </div>
            
            <div className="flex justify-between mt-4">
              <Button
                onClick={onPreviousStep}
                className="px-4 py-2 border border-slate-300 rounded-lg text-slate-700"
                variant="outline"
              >
                Back
              </Button>
              
              <Button
                onClick={onComplete}
                className="px-4 py-2 bg-primary-600 text-white rounded-lg"
              >
                Complete
              </Button>
            </div>
          </div>
        );
        
      default:
        return null;
    }
  };
  
  return (
    <div>
      {renderStepContent()}
    </div>
  );
}
