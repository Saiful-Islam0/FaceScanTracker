import { User } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { User as UserIcon, CheckCircle } from "lucide-react";
import { format } from "date-fns";

type RecognitionResultProps = {
  user: User;
  date: string;
  time: string;
  onMarkAttendance: () => void;
  isPending: boolean;
};

export default function RecognitionResult({
  user,
  date,
  time,
  onMarkAttendance,
  isPending
}: RecognitionResultProps) {
  return (
    <div className="rounded-xl bg-white shadow p-4 mb-4">
      <div className="flex items-center mb-2">
        <div className="w-10 h-10 rounded-full bg-primary-100 flex items-center justify-center mr-3">
          <UserIcon className="h-5 w-5 text-primary-600" />
        </div>
        <div>
          <h3 className="font-medium">{user.fullName}</h3>
          <p className="text-xs text-slate-500">ID: {user.employeeId}</p>
        </div>
        <div className="ml-auto">
          <span className="bg-green-100 text-green-800 text-xs font-medium px-2.5 py-1 rounded">
            Recognized
          </span>
        </div>
      </div>
      <div className="flex items-center justify-between">
        <div className="text-xs text-slate-500">
          <span>{date}</span> • <span>{time}</span>
        </div>
        <Button
          onClick={onMarkAttendance}
          disabled={isPending}
          variant="ghost"
          className="text-primary-600 text-sm font-medium flex items-center"
        >
          {isPending ? (
            <span>Processing...</span>
          ) : (
            <>
              Mark Attendance
              <CheckCircle className="ml-1 h-4 w-4" />
            </>
          )}
        </Button>
      </div>
    </div>
  );
}
