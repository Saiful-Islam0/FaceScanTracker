import { useState, useRef } from "react";
import { useQuery } from "@tanstack/react-query";
import { 
  ChevronLeft, 
  ChevronRight, 
  Download, 
  Bot, 
  Send 
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Chart as ChartJS,
  ArcElement,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  ChartData
} from 'chart.js';
import { Pie, Line } from 'react-chartjs-2';
import { format, addDays, subDays, startOfWeek, subWeeks } from "date-fns";
import { useToast } from "@/hooks/use-toast";

ChartJS.register(
  ArcElement,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

const REPORT_TYPES = ["Daily", "Weekly", "Monthly", "Custom"] as const;
type ReportType = typeof REPORT_TYPES[number];

export default function ReportsView() {
  const { toast } = useToast();
  const [reportType, setReportType] = useState<ReportType>("Daily");
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [query, setQuery] = useState("");
  const [queryResult, setQueryResult] = useState<string | null>(null);
  const [queryTimestamp, setQueryTimestamp] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  
  // Format dates based on report type
  const getFormattedDate = () => {
    switch (reportType) {
      case "Daily":
        return format(selectedDate, "MMMM d, yyyy");
      case "Weekly":
        const weekStart = startOfWeek(selectedDate);
        const weekEnd = addDays(weekStart, 6);
        return `${format(weekStart, "MMM d")} - ${format(weekEnd, "MMM d, yyyy")}`;
      case "Monthly":
        return format(selectedDate, "MMMM yyyy");
      default:
        return format(selectedDate, "MMMM d, yyyy");
    }
  };
  
  // API date param
  const getApiDateParam = () => {
    return format(selectedDate, "yyyy-MM-dd");
  };
  
  // Fetch attendance summary
  const { data: summary, isLoading: isSummaryLoading } = useQuery({
    queryKey: ['/api/attendance/summary', getApiDateParam()],
    queryFn: async () => {
      const response = await fetch(`/api/attendance/summary/${getApiDateParam()}`);
      if (!response.ok) {
        throw new Error("Failed to fetch attendance summary");
      }
      return response.json();
    }
  });
  
  // Fetch weekly data for trend chart
  const { data: trendData, isLoading: isTrendLoading } = useQuery({
    queryKey: ['/api/attendance/trend', getApiDateParam()],
    queryFn: async () => {
      // For now, we'll generate mock data since we don't have a trend API endpoint
      // In a real implementation, this would fetch from the backend
      const weekStart = startOfWeek(selectedDate);
      const data = {
        labels: Array.from({ length: 7 }).map((_, i) => 
          format(addDays(weekStart, i), "EEE")
        ),
        datasets: [
          {
            label: 'Attendance Rate',
            data: Array.from({ length: 7 }).map(() => 
              Math.floor(60 + Math.random() * 40)
            ),
            borderColor: 'rgb(37, 99, 235)',
            backgroundColor: 'rgba(37, 99, 235, 0.5)',
            tension: 0.3,
          },
        ],
      };
      return data;
    }
  });
  
  // Chart data for attendance summary
  const pieChartData: ChartData<'pie'> = {
    labels: ['Present', 'Absent', 'Late'],
    datasets: [
      {
        data: [
          summary?.present || 0,
          summary?.absent || 0,
          summary?.late || 0
        ],
        backgroundColor: [
          'rgba(74, 222, 128, 0.8)',
          'rgba(248, 113, 113, 0.8)',
          'rgba(251, 146, 60, 0.8)'
        ],
        borderColor: [
          'rgb(74, 222, 128)',
          'rgb(248, 113, 113)',
          'rgb(251, 146, 60)'
        ],
        borderWidth: 1,
      },
    ],
  };
  
  // Navigation helpers
  const goToPrevious = () => {
    switch (reportType) {
      case "Daily":
        setSelectedDate(prev => subDays(prev, 1));
        break;
      case "Weekly":
        setSelectedDate(prev => subDays(prev, 7));
        break;
      case "Monthly":
        setSelectedDate(prev => {
          const date = new Date(prev);
          date.setMonth(date.getMonth() - 1);
          return date;
        });
        break;
      default:
        setSelectedDate(prev => subDays(prev, 1));
    }
  };
  
  const goToNext = () => {
    switch (reportType) {
      case "Daily":
        setSelectedDate(prev => addDays(prev, 1));
        break;
      case "Weekly":
        setSelectedDate(prev => addDays(prev, 7));
        break;
      case "Monthly":
        setSelectedDate(prev => {
          const date = new Date(prev);
          date.setMonth(date.getMonth() + 1);
          return date;
        });
        break;
      default:
        setSelectedDate(prev => addDays(prev, 1));
    }
  };
  
  // Handle query submission
  const handleQuerySubmit = () => {
    if (!query.trim()) {
      toast({
        title: "Empty Query",
        description: "Please enter a question about attendance",
        variant: "destructive"
      });
      return;
    }
    
    // Process the query - in a real app, this would make a request to an AI endpoint
    const lowerQuery = query.toLowerCase();
    let result = "";
    
    if (lowerQuery.includes("who was absent") || lowerQuery.includes("absent")) {
      result = "The following employees were absent:\n\n" +
               "- David Wilson\n" +
               "- Lisa Thompson\n" +
               "- Ryan Martinez\n" +
               "- Christina Lopez";
    } else if (lowerQuery.includes("who was late") || lowerQuery.includes("late")) {
      result = "The following employees were late:\n\n" +
               "- Emily Davis\n" +
               "- Jason Miller\n" +
               "- Sarah Parker";
    } else if (lowerQuery.includes("present") || lowerQuery.includes("who was present")) {
      result = "18 employees were present today out of 25 total employees.";
    } else {
      result = "I'm sorry, I don't have enough information to answer that question. Try asking about who was present, absent, or late.";
    }
    
    setQueryResult(result);
    setQueryTimestamp(format(new Date(), "h:mm a"));
    setQuery("");
    
    toast({
      title: "Query Processed",
      description: "Your question was processed successfully",
      variant: "default"
    });
  };
  
  // Handle download report
  const downloadReport = () => {
    // In a real app, this would generate a CSV/PDF report
    toast({
      title: "Report Downloaded",
      description: "Your report has been downloaded successfully",
      variant: "default"
    });
  };
  
  return (
    <div className="h-full">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 bg-white shadow-sm">
        <h1 className="text-lg font-semibold text-slate-800">Reports</h1>
        <div className="flex items-center space-x-2">
          <Button onClick={downloadReport} variant="ghost" size="icon" className="rounded-full">
            <Download className="h-5 w-5" />
          </Button>
        </div>
      </div>
      
      {/* Report selector */}
      <div className="p-4 pb-0">
        <div className="flex overflow-x-auto space-x-2 pb-2">
          {REPORT_TYPES.map(type => (
            <Button
              key={type}
              onClick={() => setReportType(type)}
              variant={reportType === type ? "default" : "outline"}
              className={`whitespace-nowrap px-4 py-2 rounded-full text-sm font-medium ${
                reportType === type ? "bg-primary-600 text-white" : "bg-slate-100 text-slate-600"
              }`}
            >
              {type}
            </Button>
          ))}
        </div>
        
        {/* Date range */}
        <div className="flex items-center justify-between mt-4 mb-3">
          <Button
            onClick={goToPrevious}
            variant="ghost"
            size="icon"
            className="rounded-full"
          >
            <ChevronLeft className="h-5 w-5" />
          </Button>
          <h2 className="font-semibold">{getFormattedDate()}</h2>
          <Button
            onClick={goToNext}
            variant="ghost"
            size="icon"
            className="rounded-full"
          >
            <ChevronRight className="h-5 w-5" />
          </Button>
        </div>
      </div>
      
      {/* Charts and stats */}
      <div className="px-4 pb-20 space-y-4">
        {/* Attendance chart */}
        <div className="bg-white p-4 rounded-lg shadow-sm">
          <h3 className="text-sm font-medium text-slate-600 mb-2">Attendance Overview</h3>
          {isSummaryLoading ? (
            <div className="h-44 flex justify-center items-center">
              <Skeleton className="h-32 w-32 rounded-full" />
            </div>
          ) : summary?.total === 0 ? (
            <div className="h-44 flex justify-center items-center text-slate-400">
              No data available
            </div>
          ) : (
            <div className="h-44 w-full mb-2">
              <Pie 
                data={pieChartData} 
                options={{
                  responsive: true,
                  maintainAspectRatio: false,
                  plugins: {
                    legend: {
                      position: 'bottom',
                      labels: {
                        boxWidth: 12,
                        font: {
                          size: 10
                        }
                      }
                    }
                  }
                }} 
              />
            </div>
          )}
          <div className="flex justify-between text-xs text-slate-500">
            <div className="flex items-center">
              <div className="w-3 h-3 bg-green-400 rounded-sm mr-1"></div>
              <span>Present ({summary?.present || 0})</span>
            </div>
            <div className="flex items-center">
              <div className="w-3 h-3 bg-red-400 rounded-sm mr-1"></div>
              <span>Absent ({summary?.absent || 0})</span>
            </div>
            <div className="flex items-center">
              <div className="w-3 h-3 bg-orange-400 rounded-sm mr-1"></div>
              <span>Late ({summary?.late || 0})</span>
            </div>
          </div>
        </div>
        
        {/* Attendance trends */}
        <div className="bg-white p-4 rounded-lg shadow-sm">
          <h3 className="text-sm font-medium text-slate-600 mb-2">Attendance Trends</h3>
          {isTrendLoading ? (
            <div className="h-36 w-full">
              <Skeleton className="h-full w-full" />
            </div>
          ) : (
            <div className="h-36 w-full mb-2">
              <Line 
                data={trendData}
                options={{
                  responsive: true,
                  maintainAspectRatio: false,
                  plugins: {
                    legend: {
                      display: false
                    }
                  },
                  scales: {
                    y: {
                      beginAtZero: true,
                      max: 100,
                      ticks: {
                        callback: (value) => `${value}%`
                      }
                    }
                  }
                }}
              />
            </div>
          )}
        </div>
        
        {/* AI Query */}
        <div>
          <div className="relative">
            <Input
              ref={inputRef}
              type="text"
              placeholder="Ask about attendance..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  handleQuerySubmit();
                }
              }}
              className="pl-10 pr-10 py-3 bg-white rounded-full shadow-sm w-full focus:outline-none focus:ring-1 focus:ring-primary-500 text-sm"
            />
            <Bot className="absolute left-4 top-1/2 transform -translate-y-1/2 text-primary-500 h-5 w-5" />
            <Button
              onClick={handleQuerySubmit}
              variant="ghost"
              size="icon"
              className="absolute right-3 top-1/2 transform -translate-y-1/2 text-primary-600 h-6 w-6"
            >
              <Send className="h-4 w-4" />
            </Button>
          </div>
        </div>
        
        {/* Query results */}
        {queryResult && (
          <div className="bg-white p-4 rounded-lg shadow-sm">
            <div className="flex items-start mb-3">
              <div className="w-8 h-8 rounded-full bg-primary-100 flex items-center justify-center mr-3 flex-shrink-0">
                <Bot className="h-4 w-4 text-primary-600" />
              </div>
              <div>
                <p className="text-sm text-slate-700 mb-1">Query: "{query || "Who was absent today?"}"</p>
                <p className="text-sm text-slate-600 whitespace-pre-line">
                  {queryResult}
                </p>
              </div>
            </div>
            <div className="text-xs text-slate-500 flex items-center mt-2">
              <span>{queryTimestamp}</span>
              <div className="ml-auto flex items-center space-x-2">
                <Button
                  onClick={() => {
                    navigator.clipboard.writeText(queryResult);
                    toast({
                      title: "Copied",
                      description: "Text copied to clipboard",
                      variant: "default"
                    });
                  }}
                  variant="ghost"
                  size="icon"
                  className="h-6 w-6 text-slate-400 hover:text-slate-600"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
                    <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
                  </svg>
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-6 w-6 text-slate-400 hover:text-slate-600"
                >
                  <Download className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
