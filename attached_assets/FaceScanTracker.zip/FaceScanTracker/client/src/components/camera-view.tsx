import { useState, useEffect, useRef } from "react";
import { useFaceDetection } from "@/hooks/use-face-detection";
import { useFaceRecognition } from "@/hooks/use-face-recognition";
import { Camera, FlipHorizontal, Zap, ZapOff } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import RecognitionResult from "./recognition-result";
import { User } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

export default function CameraView() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isCameraOn, setIsCameraOn] = useState(false);
  const [facingMode, setFacingMode] = useState<"user" | "environment">("user");
  const [flashOn, setFlashOn] = useState(false);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const { videoRef, faces, isDetecting, startDetection, stopDetection } = useFaceDetection();
  const { recognizedUser, recognizeFace, isRecognizing } = useFaceRecognition();
  const [recentActivity, setRecentActivity] = useState<Array<{
    user: User;
    time: string;
    action: string;
  }>>([]);

  // Set up camera
  useEffect(() => {
    async function setupCamera() {
      try {
        if (isCameraOn) {
          // Stop any existing stream
          if (stream) {
            stream.getTracks().forEach(track => track.stop());
          }

          // Start new stream with facing mode
          const newStream = await navigator.mediaDevices.getUserMedia({
            video: {
              facingMode,
              width: { ideal: 640 },
              height: { ideal: 480 }
            },
            audio: false
          });

          // Set stream to state and video element
          setStream(newStream);
          if (videoRef.current) {
            videoRef.current.srcObject = newStream;
            
            // Start detection after camera is ready
            videoRef.current.onloadedmetadata = () => {
              startDetection();
            };
          }
        } else {
          // Stop detection and stream when camera is turned off
          stopDetection();
          if (stream) {
            stream.getTracks().forEach(track => track.stop());
            setStream(null);
          }
        }
      } catch (error) {
        console.error("Error accessing camera:", error);
        toast({
          title: "Camera Error",
          description: "Could not access the camera. Please check permissions.",
          variant: "destructive"
        });
      }
    }

    setupCamera();

    return () => {
      stopDetection();
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, [isCameraOn, facingMode, videoRef, startDetection, stopDetection, stream, toast]);

  // Turn camera on when component mounts
  useEffect(() => {
    setIsCameraOn(true);
  }, []);

  // Toggle camera facing mode
  const toggleCamera = () => {
    setFacingMode(prev => prev === "user" ? "environment" : "user");
  };

  // Toggle flash
  const toggleFlash = () => {
    setFlashOn(prev => !prev);
    if (stream) {
      const track = stream.getVideoTracks()[0];
      if (track.getCapabilities().torch) {
        track.applyConstraints({
          advanced: [{ torch: !flashOn }]
        }).catch(error => {
          console.error("Error toggling flash:", error);
        });
      } else {
        toast({
          title: "Flash Unavailable",
          description: "Flash is not supported on this device",
          variant: "destructive"
        });
      }
    }
  };

  // Capture and recognize face
  const captureFace = async () => {
    if (!videoRef.current || isRecognizing) return;
    
    try {
      const user = await recognizeFace(videoRef.current);
      
      if (!user) {
        toast({
          title: "Recognition Failed",
          description: "No matching face found. Please try again or enroll this person.",
          variant: "destructive"
        });
      }
    } catch (error) {
      console.error("Error capturing face:", error);
      toast({
        title: "Recognition Error",
        description: "An error occurred during face recognition.",
        variant: "destructive"
      });
    }
  };

  // Mark attendance mutation
  const markAttendanceMutation = useMutation({
    mutationFn: async (userId: number) => {
      return apiRequest("POST", "/api/attendance", {
        userId,
        status: "present",
        type: "check-in"
      });
    },
    onSuccess: async (_, userId) => {
      // Update recent activity
      if (recognizedUser) {
        setRecentActivity(prev => [
          {
            user: recognizedUser,
            time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            action: "Check-in recorded"
          },
          ...prev.slice(0, 4) // Keep only the 5 most recent activities
        ]);
      }
      
      // Show success message
      toast({
        title: "Attendance Marked",
        description: "Attendance has been successfully recorded",
        variant: "default"
      });
      
      // Invalidate relevant queries
      queryClient.invalidateQueries({ queryKey: ['/api/attendance'] });
    },
    onError: (error) => {
      console.error("Error marking attendance:", error);
      toast({
        title: "Attendance Error",
        description: "Failed to mark attendance. Please try again.",
        variant: "destructive"
      });
    }
  });

  // Handle attendance marking
  const handleMarkAttendance = () => {
    if (!recognizedUser) return;
    
    markAttendanceMutation.mutate(recognizedUser.id);
  };

  // Get current date and time
  const getCurrentDateTime = () => {
    const now = new Date();
    const dateOptions: Intl.DateTimeFormatOptions = { 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    };
    const timeOptions: Intl.DateTimeFormatOptions = { 
      hour: '2-digit', 
      minute: '2-digit' 
    };
    
    return {
      date: now.toLocaleDateString(undefined, dateOptions),
      time: now.toLocaleTimeString(undefined, timeOptions)
    };
  };

  const { date, time } = getCurrentDateTime();

  return (
    <div className="h-full">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 bg-white shadow-sm">
        <h1 className="text-lg font-semibold text-slate-800">Face Attendance</h1>
        <div className="flex items-center space-x-2">
          <Button variant="ghost" size="icon" className="rounded-full">
            <Camera className="h-5 w-5" />
          </Button>
        </div>
      </div>
      
      {/* Camera viewfinder */}
      <div className="w-full aspect-[3/4] bg-black mx-auto relative">
        <video
          ref={videoRef}
          autoPlay
          playsInline
          muted
          className="w-full h-full object-cover"
        />
        
        {/* Face detection overlays */}
        {faces.map((face, index) => (
          <div
            key={index}
            className="absolute border-2 border-primary-600 rounded-lg"
            style={{
              top: `${face.topLeft[1]}px`,
              left: `${face.topLeft[0]}px`,
              width: `${face.bottomRight[0] - face.topLeft[0]}px`,
              height: `${face.bottomRight[1] - face.topLeft[1]}px`,
              animation: "pulse 1.5s infinite"
            }}
          >
            <div className="absolute -top-6 left-1/2 transform -translate-x-1/2 bg-primary-600 text-white px-3 py-1 rounded-full text-xs font-medium">
              {isRecognizing ? "Recognizing..." : "Detecting..."}
            </div>
          </div>
        ))}
        
        {/* Camera controls */}
        <div className="absolute bottom-4 left-0 w-full flex justify-center space-x-6">
          <Button
            onClick={toggleCamera}
            className="w-14 h-14 bg-white rounded-full flex items-center justify-center shadow-lg hover:bg-slate-100"
          >
            <FlipHorizontal className="h-6 w-6 text-slate-700" />
          </Button>
          
          <Button
            onClick={captureFace}
            disabled={isRecognizing || !isDetecting}
            className="w-16 h-16 bg-primary-600 rounded-full flex items-center justify-center shadow-lg hover:bg-primary-700"
          >
            <Camera className="h-7 w-7 text-white" />
          </Button>
          
          <Button
            onClick={toggleFlash}
            className="w-14 h-14 bg-white rounded-full flex items-center justify-center shadow-lg hover:bg-slate-100"
          >
            {flashOn ? 
              <ZapOff className="h-6 w-6 text-slate-700" /> : 
              <Zap className="h-6 w-6 text-slate-700" />
            }
          </Button>
        </div>
      </div>
      
      {/* Recognition results */}
      <div className="p-4 pb-20">
        {recognizedUser && (
          <RecognitionResult
            user={recognizedUser}
            date={date}
            time={time}
            onMarkAttendance={handleMarkAttendance}
            isPending={markAttendanceMutation.isPending}
          />
        )}
        
        {/* Recent Activity */}
        <h3 className="font-medium text-sm text-slate-600 mb-2">Recent Activity</h3>
        <div className="space-y-3">
          {recentActivity.length > 0 ? (
            recentActivity.map((activity, index) => (
              <div
                key={index}
                className="attendance-card flex items-center p-3 bg-white rounded-lg shadow-sm"
              >
                <div className="w-10 h-10 rounded-full bg-slate-200 flex items-center justify-center mr-3">
                  <div className="text-slate-500 font-medium">
                    {activity.user.fullName.split(' ').map(n => n[0]).join('')}
                  </div>
                </div>
                <div className="flex-1">
                  <div className="flex justify-between">
                    <h4 className="font-medium text-sm">{activity.user.fullName}</h4>
                    <span className="text-xs text-slate-500">{activity.time}</span>
                  </div>
                  <p className="text-xs text-slate-500">{activity.action}</p>
                </div>
              </div>
            ))
          ) : (
            <div className="p-4 text-center text-sm text-slate-500">
              No recent activity
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
