import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, MoreHorizontal, UserPlus, X } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import EnrollmentForm from "./enrollment-form";
import { User } from "@shared/schema";
import { format, parseISO } from "date-fns";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";

export default function EnrollmentView() {
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState("");
  const [isEnrollmentFormOpen, setIsEnrollmentFormOpen] = useState(false);
  const [currentStep, setCurrentStep] = useState(1);
  const [enrollmentFormData, setEnrollmentFormData] = useState<Partial<User>>({});
  
  // Fetch enrolled users
  const { data: users, isLoading, error } = useQuery({
    queryKey: ['/api/users'],
    queryFn: async () => {
      const response = await fetch('/api/users');
      if (!response.ok) {
        throw new Error("Failed to fetch users");
      }
      return response.json();
    }
  });
  
  // Filter users based on search term
  const filteredUsers = users ? 
    users.filter((user: User) => 
      user.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.employeeId.toLowerCase().includes(searchTerm.toLowerCase())
    ) : [];
  
  // Handle user deletion
  const handleDeleteUser = async (userId: number) => {
    try {
      await apiRequest("DELETE", `/api/users/${userId}`);
      queryClient.invalidateQueries({ queryKey: ['/api/users'] });
      toast({
        title: "User Deleted",
        description: "User has been successfully deleted",
        variant: "default"
      });
    } catch (error) {
      console.error("Error deleting user:", error);
      toast({
        title: "Error",
        description: "Failed to delete user",
        variant: "destructive"
      });
    }
  };
  
  // Open enrollment form
  const openEnrollmentForm = () => {
    setIsEnrollmentFormOpen(true);
    setCurrentStep(1);
    setEnrollmentFormData({});
  };
  
  // Close enrollment form
  const closeEnrollmentForm = () => {
    setIsEnrollmentFormOpen(false);
  };
  
  // Handle form step navigation
  const goToNextStep = (data: Partial<User>) => {
    setEnrollmentFormData({ ...enrollmentFormData, ...data });
    setCurrentStep(step => step + 1);
  };
  
  const goToPreviousStep = () => {
    setCurrentStep(step => Math.max(1, step - 1));
  };
  
  // Complete enrollment
  const completeEnrollment = () => {
    // In a real app, this would submit the full enrollment data
    setIsEnrollmentFormOpen(false);
    setCurrentStep(1);
    queryClient.invalidateQueries({ queryKey: ['/api/users'] });
    toast({
      title: "Enrollment Completed",
      description: "User has been successfully enrolled",
      variant: "default"
    });
  };
  
  return (
    <div className="h-full">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 bg-white shadow-sm">
        <h1 className="text-lg font-semibold text-slate-800">Enrollment</h1>
        <div className="flex items-center space-x-2">
          <Button
            onClick={openEnrollmentForm}
            className="text-sm bg-primary-600 text-white px-4 py-1.5 rounded-full flex items-center"
          >
            <UserPlus className="h-4 w-4 mr-1" />
            Add New
          </Button>
        </div>
      </div>
      
      {/* Enrollment list */}
      <div className="p-4 pb-20">
        <div className="flex justify-between items-center mb-3">
          <h3 className="font-medium text-sm text-slate-600">Enrolled Personnel</h3>
          <div className="relative">
            <Input
              type="text"
              placeholder="Search..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-8 pr-3 py-1 text-sm bg-slate-100 rounded-full w-36 focus:outline-none focus:ring-1 focus:ring-primary-500"
            />
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 h-4 w-4" />
          </div>
        </div>
        
        <div className="space-y-3">
          {isLoading ? (
            // Loading skeleton
            Array.from({ length: 3 }).map((_, index) => (
              <div key={index} className="bg-white rounded-lg p-3 shadow-sm">
                <div className="flex items-center">
                  <Skeleton className="h-10 w-10 rounded-full mr-3" />
                  <div className="flex-1">
                    <Skeleton className="h-4 w-24 mb-2" />
                    <Skeleton className="h-3 w-32" />
                  </div>
                </div>
              </div>
            ))
          ) : error ? (
            <div className="text-center p-4 text-red-500">
              Error loading enrolled users
            </div>
          ) : filteredUsers.length === 0 ? (
            <div className="text-center p-4 text-slate-500">
              {searchTerm ? "No matching users found" : "No users enrolled yet"}
            </div>
          ) : (
            filteredUsers.map((user: User) => (
              <div
                key={user.id}
                className="attendance-card flex items-center p-3 bg-white rounded-lg shadow-sm"
              >
                <div className="w-10 h-10 rounded-full bg-slate-200 mr-3 flex items-center justify-center">
                  <div className="text-slate-500 font-medium">
                    {user.fullName.split(' ').map(n => n[0]).join('')}
                  </div>
                </div>
                <div className="flex-1">
                  <div className="flex justify-between">
                    <h4 className="font-medium text-sm">{user.fullName}</h4>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-8 w-8 text-slate-400">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onSelect={() => handleDeleteUser(user.id)}>
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                  <div className="flex justify-between mt-1">
                    <p className="text-xs text-slate-500">ID: {user.employeeId}</p>
                    <p className="text-xs text-slate-500">
                      Enrolled: {format(
                        typeof user.enrollmentDate === 'string' 
                          ? parseISO(user.enrollmentDate) 
                          : user.enrollmentDate, 
                        "MMM dd, yyyy"
                      )}
                    </p>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
      
      {/* Enrollment bottom sheet */}
      <div className={`bottom-sheet fixed inset-x-0 bottom-0 bg-white rounded-t-xl shadow-lg z-20 h-[80%] ${isEnrollmentFormOpen ? 'open' : ''}`}>
        <div className="p-4">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-lg font-semibold">New Enrollment</h2>
            <Button
              onClick={closeEnrollmentForm}
              variant="ghost"
              size="icon"
              className="h-8 w-8"
            >
              <X className="h-5 w-5" />
            </Button>
          </div>
          
          {/* Enrollment steps */}
          <div className="enrollment-steps flex items-center justify-between mb-6">
            <div className={`flex flex-col items-center ${currentStep === 1 ? 'active' : ''}`}>
              <div className={`w-8 h-8 rounded-full ${currentStep === 1 ? 'bg-primary-600 text-white' : 'bg-slate-200 text-slate-500'} flex items-center justify-center mb-1`}>
                1
              </div>
              <span className="text-xs text-slate-500">Info</span>
            </div>
            <div className="flex-1 h-0.5 bg-slate-200 mx-2"></div>
            <div className={`flex flex-col items-center ${currentStep === 2 ? 'active' : ''}`}>
              <div className={`w-8 h-8 rounded-full ${currentStep === 2 ? 'bg-primary-600 text-white' : 'bg-slate-200 text-slate-500'} flex items-center justify-center mb-1`}>
                2
              </div>
              <span className="text-xs text-slate-500">Face Scan</span>
            </div>
            <div className="flex-1 h-0.5 bg-slate-200 mx-2"></div>
            <div className={`flex flex-col items-center ${currentStep === 3 ? 'active' : ''}`}>
              <div className={`w-8 h-8 rounded-full ${currentStep === 3 ? 'bg-primary-600 text-white' : 'bg-slate-200 text-slate-500'} flex items-center justify-center mb-1`}>
                3
              </div>
              <span className="text-xs text-slate-500">Confirm</span>
            </div>
          </div>
          
          <EnrollmentForm
            currentStep={currentStep}
            formData={enrollmentFormData}
            onNextStep={goToNextStep}
            onPreviousStep={goToPreviousStep}
            onComplete={completeEnrollment}
          />
        </div>
      </div>
    </div>
  );
}
