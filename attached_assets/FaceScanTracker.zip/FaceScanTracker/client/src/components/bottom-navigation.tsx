import { ReactNode } from "react";
import { Camera, FileText, BarChart2, UserPlus } from "lucide-react";

type Tab = {
  id: string;
  label: string;
  icon: ReactNode;
};

type BottomNavigationProps = {
  activeTab: string;
  onChange: (tabId: string) => void;
};

export default function BottomNavigation({ activeTab, onChange }: BottomNavigationProps) {
  const tabs: Tab[] = [
    {
      id: "camera",
      label: "Camera",
      icon: <Camera className="text-xl" />
    },
    {
      id: "attendance",
      label: "Attendance",
      icon: <FileText className="text-xl" />
    },
    {
      id: "reports",
      label: "Reports",
      icon: <BarChart2 className="text-xl" />
    },
    {
      id: "enrollment",
      label: "Enroll",
      icon: <UserPlus className="text-xl" />
    }
  ];
  
  // Calculate tab indicator position
  const getTabIndicatorStyle = () => {
    const index = tabs.findIndex(tab => tab.id === activeTab);
    const position = index >= 0 ? index : 0;
    return {
      width: "25%",
      left: `${position * 25}%`
    };
  };
  
  return (
    <div className="bg-white border-t border-slate-200 fixed bottom-0 left-0 right-0">
      <div className="relative">
        <div 
          className="tab-indicator absolute h-1 bg-primary-600 rounded-full transition-all duration-300"
          style={getTabIndicatorStyle()}
        />
      </div>
      <div className="flex justify-around">
        {tabs.map((tab) => {
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => onChange(tab.id)}
              className={`py-3 px-2 flex flex-col items-center w-1/4 ${isActive ? 'active' : ''}`}
            >
              <div className={isActive ? "text-primary-600" : "text-slate-500"}>
                {tab.icon}
              </div>
              <span 
                className={`text-xs mt-1 ${
                  isActive 
                    ? "text-primary-600 font-medium" 
                    : "text-slate-500"
                }`}
              >
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
