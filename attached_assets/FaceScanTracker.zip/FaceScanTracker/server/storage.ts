import { 
  users, type User, type InsertUser,
  attendance, type Attendance, type InsertAttendance,
  type AttendanceQuery, type AnalyticsQuery
} from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmployeeId(employeeId: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, userData: Partial<InsertUser>): Promise<User | undefined>;
  deleteUser(id: number): Promise<boolean>;
  getAllUsers(): Promise<User[]>;
  
  // Attendance operations
  createAttendance(attendance: InsertAttendance): Promise<Attendance>;
  getAttendance(id: number): Promise<Attendance | undefined>;
  getUserAttendance(userId: number): Promise<Attendance[]>;
  getAttendanceByDate(date: string): Promise<Attendance[]>;
  queryAttendance(query: AttendanceQuery): Promise<Attendance[]>;
  getAttendanceSummary(date: string): Promise<{
    present: number,
    absent: number,
    late: number,
    total: number
  }>;
  
  // Analytics operations
  getAttendanceAnalytics(query: AnalyticsQuery): Promise<any>;
  getPredictiveInsights(userId?: number): Promise<any>;
  getAttendanceTrends(startDate: string, endDate: string): Promise<any>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private attendance: Map<number, Attendance>;
  private userIdCounter: number;
  private attendanceIdCounter: number;

  constructor() {
    this.users = new Map();
    this.attendance = new Map();
    this.userIdCounter = 1;
    this.attendanceIdCounter = 1;
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async getUserByEmployeeId(employeeId: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.employeeId === employeeId,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const now = new Date();
    const user: User = { 
      ...insertUser, 
      id, 
      enrollmentDate: now
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, userData: Partial<InsertUser>): Promise<User | undefined> {
    const existingUser = await this.getUser(id);
    if (!existingUser) return undefined;
    
    const updatedUser: User = {
      ...existingUser,
      ...userData,
    };
    
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async deleteUser(id: number): Promise<boolean> {
    return this.users.delete(id);
  }

  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  // Attendance operations
  async createAttendance(insertAttendance: InsertAttendance): Promise<Attendance> {
    const id = this.attendanceIdCounter++;
    const now = new Date();
    
    const attendance: Attendance = {
      ...insertAttendance,
      id,
      timestamp: now,
    };
    
    this.attendance.set(id, attendance);
    return attendance;
  }

  async getAttendance(id: number): Promise<Attendance | undefined> {
    return this.attendance.get(id);
  }

  async getUserAttendance(userId: number): Promise<Attendance[]> {
    return Array.from(this.attendance.values()).filter(
      (record) => record.userId === userId
    );
  }

  async getAttendanceByDate(dateStr: string): Promise<Attendance[]> {
    const date = new Date(dateStr);
    return Array.from(this.attendance.values()).filter((record) => {
      const recordDate = new Date(record.timestamp);
      return (
        recordDate.getFullYear() === date.getFullYear() &&
        recordDate.getMonth() === date.getMonth() &&
        recordDate.getDate() === date.getDate()
      );
    });
  }

  async queryAttendance(query: AttendanceQuery): Promise<Attendance[]> {
    let results = Array.from(this.attendance.values());
    
    if (query.userId) {
      results = results.filter(record => record.userId === query.userId);
    }
    
    if (query.status) {
      results = results.filter(record => record.status === query.status);
    }
    
    if (query.date) {
      const queryDate = new Date(query.date);
      results = results.filter(record => {
        const recordDate = new Date(record.timestamp);
        return (
          recordDate.getFullYear() === queryDate.getFullYear() &&
          recordDate.getMonth() === queryDate.getMonth() &&
          recordDate.getDate() === queryDate.getDate()
        );
      });
    }
    
    return results;
  }

  async getAttendanceSummary(dateStr: string): Promise<{
    present: number,
    absent: number,
    late: number,
    total: number
  }> {
    const attendanceRecords = await this.getAttendanceByDate(dateStr);
    const totalUsers = this.users.size;
    
    // Count unique users present on that day
    const presentUserIds = new Set<number>();
    const lateUserIds = new Set<number>();
    
    attendanceRecords.forEach(record => {
      if (record.status === 'late') {
        lateUserIds.add(record.userId);
      } else if (record.status === 'present') {
        presentUserIds.add(record.userId);
      }
    });
    
    const present = presentUserIds.size;
    const late = lateUserIds.size;
    const absent = totalUsers - present - late;
    
    return {
      present,
      absent,
      late,
      total: totalUsers
    };
  }
  
  // Analytics operations
  async getAttendanceAnalytics(query: AnalyticsQuery): Promise<any> {
    const { startDate, endDate, userId, type } = query;
    const start = new Date(startDate);
    const end = new Date(endDate);
    
    let records = Array.from(this.attendance.values()).filter(record => {
      const recordDate = new Date(record.timestamp);
      return recordDate >= start && recordDate <= end;
    });
    
    if (userId) {
      records = records.filter(record => record.userId === userId);
    }
    
    if (type === 'attendance') {
      // Group by date and count status
      const dateMap = new Map<string, { present: number, absent: number, late: number }>();
      
      // Initialize all dates in the range
      const currentDate = new Date(start);
      while (currentDate <= end) {
        const dateKey = currentDate.toISOString().split('T')[0];
        dateMap.set(dateKey, { present: 0, absent: 0, late: 0 });
        currentDate.setDate(currentDate.getDate() + 1);
      }
      
      // Count statuses by date
      records.forEach(record => {
        const dateKey = new Date(record.timestamp).toISOString().split('T')[0];
        const currentCount = dateMap.get(dateKey) || { present: 0, absent: 0, late: 0 };
        
        if (record.status === 'present') {
          currentCount.present++;
        } else if (record.status === 'late') {
          currentCount.late++;
        } else if (record.status === 'absent') {
          currentCount.absent++;
        }
        
        dateMap.set(dateKey, currentCount);
      });
      
      return {
        dateRange: Array.from(dateMap.keys()),
        statuses: Array.from(dateMap.values())
      };
    }
    
    if (type === 'trends') {
      // Calculate trends over time
      return this.getAttendanceTrends(startDate, endDate);
    }
    
    if (type === 'prediction') {
      // Generate predictive insights
      return this.getPredictiveInsights(userId);
    }
    
    return { message: "Invalid analytics type" };
  }
  
  async getPredictiveInsights(userId?: number): Promise<any> {
    // Get all attendance records
    let records = Array.from(this.attendance.values());
    
    if (userId) {
      records = records.filter(record => record.userId === userId);
    }
    
    // Sort records by timestamp
    records.sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
    
    // Calculate attendance patterns
    const userPatterns: Record<number, { 
      regularAttendance: boolean,
      avgCheckInTime: string,
      lateFrequency: number,
      attendanceRate: number,
      prediction: string
    }> = {};
    
    // Group records by user
    const userRecords: Record<number, Attendance[]> = {};
    records.forEach(record => {
      if (!userRecords[record.userId]) {
        userRecords[record.userId] = [];
      }
      userRecords[record.userId].push(record);
    });
    
    // Calculate patterns for each user
    for (const [userId, records] of Object.entries(userRecords)) {
      const totalDays = records.length;
      const lateDays = records.filter(r => r.status === 'late').length;
      const presentDays = records.filter(r => r.status === 'present').length;
      
      // Calculate average check-in time
      let totalMinutes = 0;
      records.forEach(record => {
        const date = new Date(record.timestamp);
        totalMinutes += date.getHours() * 60 + date.getMinutes();
      });
      
      const avgMinutes = totalMinutes / totalDays;
      const avgHours = Math.floor(avgMinutes / 60);
      const avgMins = Math.floor(avgMinutes % 60);
      const avgCheckInTime = `${avgHours.toString().padStart(2, '0')}:${avgMins.toString().padStart(2, '0')}`;
      
      // Calculate attendance rate
      const attendanceRate = ((presentDays + lateDays) / totalDays) * 100;
      
      // Calculate late frequency
      const lateFrequency = (lateDays / totalDays) * 100;
      
      // Determine if the user has regular attendance
      const regularAttendance = lateFrequency < 20 && attendanceRate > 80;
      
      // Generate prediction message
      let prediction = "Regular attendance expected";
      if (lateFrequency > 30) {
        prediction = "High probability of late arrival";
      } else if (attendanceRate < 70) {
        prediction = "Attendance may be inconsistent";
      }
      
      userPatterns[Number(userId)] = {
        regularAttendance,
        avgCheckInTime,
        lateFrequency,
        attendanceRate,
        prediction
      };
    }
    
    if (userId) {
      return userPatterns[userId] || {
        regularAttendance: false,
        avgCheckInTime: "N/A",
        lateFrequency: 0,
        attendanceRate: 0,
        prediction: "Insufficient data for prediction"
      };
    }
    
    return userPatterns;
  }
  
  async getAttendanceTrends(startDate: string, endDate: string): Promise<any> {
    const start = new Date(startDate);
    const end = new Date(endDate);
    
    const records = Array.from(this.attendance.values()).filter(record => {
      const recordDate = new Date(record.timestamp);
      return recordDate >= start && recordDate <= end;
    });
    
    // Group records by date
    const recordsByDate: Record<string, Attendance[]> = {};
    records.forEach(record => {
      const dateKey = new Date(record.timestamp).toISOString().split('T')[0];
      if (!recordsByDate[dateKey]) {
        recordsByDate[dateKey] = [];
      }
      recordsByDate[dateKey].push(record);
    });
    
    // Initialize date range
    const dateRange: string[] = [];
    const presentCount: number[] = [];
    const lateCount: number[] = [];
    const absentCount: number[] = [];
    
    // Fill the date range
    const currentDate = new Date(start);
    const totalUsers = this.users.size;
    while (currentDate <= end) {
      const dateKey = currentDate.toISOString().split('T')[0];
      dateRange.push(dateKey);
      
      const dayRecords = recordsByDate[dateKey] || [];
      const presentUserIds = new Set<number>();
      const lateUserIds = new Set<number>();
      
      dayRecords.forEach(record => {
        if (record.status === 'present') {
          presentUserIds.add(record.userId);
        } else if (record.status === 'late') {
          lateUserIds.add(record.userId);
        }
      });
      
      presentCount.push(presentUserIds.size);
      lateCount.push(lateUserIds.size);
      absentCount.push(totalUsers - presentUserIds.size - lateUserIds.size);
      
      currentDate.setDate(currentDate.getDate() + 1);
    }
    
    return {
      dateRange,
      trends: {
        present: presentCount,
        late: lateCount,
        absent: absentCount
      }
    };
  }
}

export const storage = new MemStorage();
