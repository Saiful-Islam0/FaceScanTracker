import express, { type Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertUserSchema, 
  userFormSchema,
  insertAttendanceSchema, 
  attendanceQuerySchema,
  analyticsQuerySchema
} from "@shared/schema";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  // API routes
  const apiRouter = express.Router();

  // ----- USER ROUTES -----
  
  // Get all users
  apiRouter.get("/users", async (req: Request, res: Response) => {
    try {
      const users = await storage.getAllUsers();
      res.json(users);
    } catch (error) {
      res.status(500).json({ message: "Error fetching users" });
    }
  });

  // Get user by ID
  apiRouter.get("/users/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const user = await storage.getUser(id);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: "Error fetching user" });
    }
  });

  // Create user (enrollment)
  apiRouter.post("/users", async (req: Request, res: Response) => {
    try {
      const userData = userFormSchema.parse(req.body);
      
      // Check if employee ID is already in use
      const existingUser = await storage.getUserByEmployeeId(userData.employeeId);
      if (existingUser) {
        return res.status(409).json({ message: "Employee ID already exists" });
      }
      
      // Create a username from employee ID
      userData.username = userData.employeeId.toLowerCase();
      
      const newUser = await storage.createUser(userData);
      res.status(201).json(newUser);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: fromZodError(error).message 
        });
      }
      res.status(500).json({ message: "Error creating user" });
    }
  });

  // Update user
  apiRouter.put("/users/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const userData = insertUserSchema.partial().parse(req.body);
      
      const updatedUser = await storage.updateUser(id, userData);
      
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json(updatedUser);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: fromZodError(error).message 
        });
      }
      res.status(500).json({ message: "Error updating user" });
    }
  });

  // Delete user
  apiRouter.delete("/users/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteUser(id);
      
      if (!success) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Error deleting user" });
    }
  });

  // Update face data
  apiRouter.put("/users/:id/face", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const { faceData } = req.body;
      
      if (!faceData) {
        return res.status(400).json({ message: "Face data is required" });
      }
      
      const updatedUser = await storage.updateUser(id, { faceData });
      
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json(updatedUser);
    } catch (error) {
      res.status(500).json({ message: "Error updating face data" });
    }
  });

  // ----- ATTENDANCE ROUTES -----
  
  // Create attendance record
  apiRouter.post("/attendance", async (req: Request, res: Response) => {
    try {
      const attendanceData = insertAttendanceSchema.parse(req.body);
      
      // Verify that the user exists
      const user = await storage.getUser(attendanceData.userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const newAttendance = await storage.createAttendance(attendanceData);
      res.status(201).json(newAttendance);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: fromZodError(error).message 
        });
      }
      res.status(500).json({ message: "Error creating attendance record" });
    }
  });

  // Get attendance by date
  apiRouter.get("/attendance/date/:date", async (req: Request, res: Response) => {
    try {
      const date = req.params.date;
      const attendanceRecords = await storage.getAttendanceByDate(date);
      
      // Fetch user details for each attendance record
      const attendanceWithUserDetails = await Promise.all(
        attendanceRecords.map(async (record) => {
          const user = await storage.getUser(record.userId);
          return {
            ...record,
            user: user ? {
              id: user.id,
              fullName: user.fullName,
              employeeId: user.employeeId,
              department: user.department
            } : null
          };
        })
      );
      
      res.json(attendanceWithUserDetails);
    } catch (error) {
      res.status(500).json({ message: "Error fetching attendance records" });
    }
  });

  // Get attendance summary by date
  apiRouter.get("/attendance/summary/:date", async (req: Request, res: Response) => {
    try {
      const date = req.params.date;
      const summary = await storage.getAttendanceSummary(date);
      res.json(summary);
    } catch (error) {
      res.status(500).json({ message: "Error fetching attendance summary" });
    }
  });

  // Query attendance
  apiRouter.get("/attendance/query", async (req: Request, res: Response) => {
    try {
      const query = attendanceQuerySchema.parse(req.query);
      const attendanceRecords = await storage.queryAttendance(query);
      
      // Fetch user details for each attendance record
      const attendanceWithUserDetails = await Promise.all(
        attendanceRecords.map(async (record) => {
          const user = await storage.getUser(record.userId);
          return {
            ...record,
            user: user ? {
              id: user.id,
              fullName: user.fullName,
              employeeId: user.employeeId,
              department: user.department
            } : null
          };
        })
      );
      
      res.json(attendanceWithUserDetails);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: fromZodError(error).message 
        });
      }
      res.status(500).json({ message: "Error querying attendance records" });
    }
  });

  // Get user attendance
  apiRouter.get("/users/:id/attendance", async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.id);
      
      // Verify the user exists
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const attendanceRecords = await storage.getUserAttendance(userId);
      res.json(attendanceRecords);
    } catch (error) {
      res.status(500).json({ message: "Error fetching user attendance" });
    }
  });

  // ----- ANALYTICS ROUTES -----
  
  // Get analytics data
  apiRouter.get("/analytics", async (req: Request, res: Response) => {
    try {
      const query = analyticsQuerySchema.parse(req.query);
      const analytics = await storage.getAttendanceAnalytics(query);
      res.json(analytics);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: fromZodError(error).message 
        });
      }
      res.status(500).json({ message: "Error fetching analytics data" });
    }
  });
  
  // Get predictive insights
  apiRouter.get("/analytics/predictions", async (req: Request, res: Response) => {
    try {
      const userId = req.query.userId ? parseInt(req.query.userId as string) : undefined;
      const insights = await storage.getPredictiveInsights(userId);
      res.json(insights);
    } catch (error) {
      res.status(500).json({ message: "Error generating predictive insights" });
    }
  });
  
  // Get attendance trends
  apiRouter.get("/analytics/trends", async (req: Request, res: Response) => {
    try {
      const { startDate, endDate } = req.query;
      
      if (!startDate || !endDate) {
        return res.status(400).json({ message: "Start date and end date are required" });
      }
      
      const trends = await storage.getAttendanceTrends(startDate as string, endDate as string);
      res.json(trends);
    } catch (error) {
      res.status(500).json({ message: "Error fetching attendance trends" });
    }
  });
  
  // Get user analytics
  apiRouter.get("/users/:id/analytics", async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.id);
      const { startDate, endDate } = req.query;
      
      // Verify the user exists
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      if (!startDate || !endDate) {
        return res.status(400).json({ message: "Start date and end date are required" });
      }
      
      const query = analyticsQuerySchema.parse({
        userId,
        startDate,
        endDate,
        type: "attendance"
      });
      
      const analytics = await storage.getAttendanceAnalytics(query);
      res.json(analytics);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: fromZodError(error).message 
        });
      }
      res.status(500).json({ message: "Error fetching user analytics" });
    }
  });

  // Register the API routes
  app.use("/api", apiRouter);

  const httpServer = createServer(app);
  return httpServer;
}
